package com.jose.blackjack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackjackApplicationTests {

	@Test
	void contextLoads() {
	}

}
